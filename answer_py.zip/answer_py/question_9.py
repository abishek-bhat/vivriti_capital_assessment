#!/usr/bin/env python
# coding: utf-8

# In[20]:


top_row_count= 6
i = 1
while i <= top_row_count:
    j = 1
    while j <= i:
        print(("*"), end=" ")
        j = j + 1
    i = i + 1
    print('')
print("\n")
bottom_row_count = 6
for i in range(0, bottom_row_count + 1):
    for j in range(bottom_row_count - i, 0, -1):
        print("*", end=' ')
    print()


# In[ ]:




