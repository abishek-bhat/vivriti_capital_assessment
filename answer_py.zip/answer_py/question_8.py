#!/usr/bin/env python
# coding: utf-8

# In[7]:


elements = 4
variable=elements
for i in range(elements, 0, -1):
    for j in range(1, i + 1):
        if(j!=variable):
            print(j,"*",end=' ')
        else:
            print(j,end=" ")
    variable-=1
    print("")


# In[ ]:




