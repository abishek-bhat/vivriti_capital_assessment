#!/usr/bin/env python
# coding: utf-8

# In[9]:


def word_count(input):
    word_input = {}

    for word in input.split():
        word_input[word] = word_input.get(word, 0) + 1

    words = list(word_input.keys())
    words.sort()

    for w in words:
        print(f'{w}:{word_input[w]}')
frequency=input("Enter the words:")
word_count(frequency)    


# In[ ]:




