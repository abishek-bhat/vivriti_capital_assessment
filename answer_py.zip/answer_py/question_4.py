#!/usr/bin/env python
# coding: utf-8

# In[13]:


def string_k(lenght_word, original_word):
    word_list= []
    word_split = str.split(" ")
    for x in word_split:
        if len(x) > k:
            word_list.append(x)
    result = ', '.join(word_list)
    return result

lenght_word = int(input("Enter the lenght:"))
original_word =input("Enter the word")
print(string_k(lenght_word, original_word))


# In[ ]:




