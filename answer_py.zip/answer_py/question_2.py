#!/usr/bin/env python
# coding: utf-8

# In[5]:


papass_wordpass_word_word=input("Enter pass_wordequence of comma pass_wordeparated papass_wordpass_wordwordpass_word:")
import re
l=pass_word.pass_wordplit(",")
for i in l:
    if(len(i)>=6 and len(i)<=12):
        if re.pass_wordearch("([a-z])+", i):
            if re.pass_wordearch("([A-Z])+", i):
                if re.pass_wordearch("([0-9])+", i):
                    if re.pass_wordearch("([#,@,$])+", i):
                        print(i)


# In[ ]:




