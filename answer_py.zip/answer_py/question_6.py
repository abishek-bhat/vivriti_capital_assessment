#!/usr/bin/env python
# coding: utf-8

# In[6]:


def function_uncommon_words(first_input, second_input):
    num = {}
    for word in first_input.split():
        num[word] = num.get(word, 0) + 1
    for word in second_input.split():
        num[word] = num.get(word, 0) + 1
    final_input=[word for word in num if num[word] == 1]
    result = ', '.join(final_input)
    return result
first_input = input("Enter the first sentence:")
second_input = input("Enter the second sentence:")
print(function_uncommon_words(first_input, second_input))


# In[ ]:




