#!/usr/bin/env python
# coding: utf-8

# In[2]:


row_input = int(input("Input number of rows: "))
column_input = int(input("Input number of columns: "))
final_combination_list = [[0 for col in range(column_input)] for row in range(row_input)]

for row in range(row_input):
    for col in range(column_input):
        final_combination_list[row][col]= row*col

print(final_combination_list)


# In[ ]:




