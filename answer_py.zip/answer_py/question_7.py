#!/usr/bin/env python
# coding: utf-8

# In[33]:


rows_count = 6
for i in range(0, rows_count):
    for j in range(rows_count - 1, i, -1):
        print(j, '', end='')
    for l in range(i):
        print('    ', end='')
    for k in range(i + 1, rows_count):
        print(k, '', end='')
    print('\n')


# In[ ]:




