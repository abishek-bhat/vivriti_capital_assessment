#!/usr/bin/env python
# coding: utf-8

# In[4]:


from re import sub

def camel_case(s):
  s = sub(r"(_|-)+", " ", s).title().replace(" ", "")
  return ''.join([s[0].lower(), s[1:]])
string_input=input("Enter the Word:")
print(camel_case(string_input))


# In[ ]:





# In[ ]:




